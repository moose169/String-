﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ThinkLib;

namespace WpfApplication3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        int Question1(string a)
        {
            if (a == "")
            {
                return 0;
            }
            else
            {
                return a.Length;
            }
        }

        private void Len_of_string_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(Question1("a"), 1);
            Tester.TestEq(Question1("ab"), 2);
            Tester.TestEq(Question1("car"), 3);
            Tester.TestEq(Question1("1085"), 4);
            Tester.TestEq(Question1("baby"), 4);
            Tester.TestEq(Question1("40807"), 5);
            Tester.TestEq(Question1("24"), 2);
            Tester.TestEq(Question1(" "), 1);
            Tester.TestEq(Question1("hello"), 5);
            Tester.TestEq(Question1("how low can you go"), 18);
        }
        bool Question2(string a,string v)
        {
            int y = a.Length;
            int x = 0;
            while (y > x)
            {
                if (Convert.ToString(a[x]) == v)
                {
                    return true;
                }
                x++;
            }
            return false;

        }
        int Question3(string a, string v)
        {
            int y = a.Length;
            int x = 0;
            while (y > x)
            {
                if (Convert.ToString(a[x]) == v)
                {
                    return x;
                }
                x++;
            }
            return -1;
        }



        private void button_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(Question2("a", "b"), false);
            Tester.TestEq(Question2("ab", "b"), true);
            Tester.TestEq(Question2("car", "b"), false);
            Tester.TestEq(Question2("1085","0"), true);
            Tester.TestEq(Question2("baby", "l"), false);
            Tester.TestEq(Question2("40807", "2"), false);
            Tester.TestEq(Question2("24", "0"), false);
            Tester.TestEq(Question2(" ", "b"), false);
            Tester.TestEq(Question2("hello", "l"), true);
            Tester.TestEq(Question2("xxyxx", "y"), true);
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(Question3("ab", "b"), 1);
            Tester.TestEq(Question3("1085", "0"), 1);
            Tester.TestEq(Question3("hello", "l"),2);
            Tester.TestEq(Question3("xxyxx", "y"),2);
         
        }
        string Question4(string a, string b, int c)
        {
            return a + b;
        }



        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(Question4("a", "b", 1), "ab");
            Tester.TestEq(Question4("ab", "b", 2), "abb");
            Tester.TestEq(Question4("car", "b", 4), "carb");
          Tester.TestEq(Question4("baby", "l", 4), "babyl");
            Tester.TestEq(Question4("40807", "2", 6), "408072");
            Tester.TestEq(Question4("24", "0", 2), "240");
        }
    }
}
